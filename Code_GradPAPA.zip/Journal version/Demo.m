clc; clear; close all;
addpath(genpath(cd));
% rng('default');
% ============================================

%% load SRI 
load SimulatedTerrainDataset.mat
SRI = img_syn/(max(img_syn(:)));
S_true = S_low_pass';
C_true = M;

% SRI  = reshape(S_true*C_true',[500, 307, 166]);
SRI_true = SRI;
[I, J, K] = size(SRI);

R  = 5;  % material = 5;
S3 = reshape(SRI, [I*J, K]); % mode 3 matricization

%% add noise to the SRI
signal_power = norm(S3,'fro')^2/(I*J*K);
SNR = 45;
noise_power = signal_power/10^(SNR/10);
noise_ten   = sqrt(noise_power)*randn(I,J,K);
noise = reshape(noise_ten,[I*J*K,1]);
noise_power = norm(noise)^2/(I*J*K);
SRI_noi = SRI + noise_ten;

%% SPA+NMF initialization
L = 100;
[Cini, index] = SPA(SRI_noi, R);
Cini = max(0, Cini); 
Sini = reshape(SRI_noi, [I*J, K])*Cini/(Cini'*Cini);
Sini = max(0, Sini); 
% Sm = reshape(S, [I, J, R]);
Aini = []; Bini = [];
for r = 1:R
    Sr = reshape(Sini(:,r), [I J]);
    [Ar, Br] = nmf(Sr, L, 'verbose', 1, 'method', 'hals');
    Ar = max(Ar, 1e-4);
    Br = max(Br, 1e-4);
    Aini = [Aini, Ar];
    Bini = [Bini, Br'];
    Sini(:,r) = reshape(Ar*Br, [I*J, 1]);
end
  

%% GradPAPALR
fprintf('\n');
disp(['performing ','GradPAPA-LR', ' ... ']);
opts.outloop = 2500; 
opts.inner   = 1;
opts.epsilon = 1e-5; 
    
L = 100;
eta = 0.0001;

tic;
[S, C, out] = GradPAPA_LR(SRI_noi, L, Sini, Cini, opts, eta, S_true, C_true);
time = toc;
      
mse_C = MSE_measure(C, C_true);
mse_S = MSE_measure(S, S_true); 
%     SRI_est = reshape(S*C', [I, J, K]); % MSI 
%     sam     = SAM(SRI_est, SRI_true);
  
display(sprintf('mse_C=%.4f,mse_S=%.4f,eta=%.5f,L=%.0f', mse_C, mse_S, eta, L))
display(sprintf('=================================='))
    

%% GradPAPANN
fprintf('\n');
disp(['performing ','GradPAPA-NN', ' ... ']);
opts.outloop = 2500; 
opts.inner   = 1;
opts.epsilon = 1e-5; 
    
L_tilde = 750;
eta = 0.0001;

tic;
[S, C, out] = GradPAPA_NN(SRI_noi, L_tilde, Sini, Cini, opts, eta, S_true, C_true);
time = toc;
      
mse_C = MSE_measure(C, C_true);
mse_S = MSE_measure(S, S_true); 
%     SRI_est = reshape(S*C', [I, J, K]); % MSI 
%     sam     = SAM(SRI_est, SRI_true);
  
display(sprintf('mse_C=%.4f,mse_S=%.4f,eta=%.5f,L=%.0f', mse_C, mse_S, eta, L))
display(sprintf('=================================='))

