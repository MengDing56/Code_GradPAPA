function [C, index] = SPA(X, R)

[I, J, K] = size(X);
X3 = reshape(X,[I*J, K]);

C = [];
index = [];
P = eye(K);
for r = 1:R
    S2 = sum((P*X3').^2,1);
    temp_index = find(S2 == max(S2(:)));
    index(r,1) = temp_index(1);
    C(:,r) = X3(index(r),:)';
    temp_P = P*C(:,r);
    P = (eye(K) - temp_P*temp_P'/sum(temp_P.^2))*P;   
end
end