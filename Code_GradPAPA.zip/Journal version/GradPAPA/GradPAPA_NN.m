function [S, C, out] = GradPAPA_NN(SRI, L, S, C, opts, eta, S_true, C_true)
% BTD algorithm
outloop = opts.outloop;
% inner   = opts.inner;
epsilon = opts.epsilon; 

q = 0.5; epsi = 1e-3;

[I, J, K] = size(SRI);
Y3 = reshape(SRI, [I*J, K]);
R  = size(S, 2);%material number

H1 = diag(ones(I, 1));
H2 = diag(-ones(I-1, 1), 1);
H  = H1 + H2;
H(I,1) = -1;

temp_H = svd(H);
sig_H  = max(temp_H);

% crate sparse HX        
HX = kron(sparse(H), sparse(eye([J,J])));
sig_HX = sig_H;

% crate sparse HY        
HY = kron(sparse(eye([J,J])), sparse(H));
sig_HY = sig_H;

S_M = cell(size(S,2), 1);
U   = cell(size(S,2), 1);
V   = cell(size(S,2), 1);

MSE_C(1) = MSE_measure(C, C_true);
MSE_S(1) = MSE_measure(S, S_true);
obj(1) = f(SRI, S, C, eta, q, epsi, HX, HY);
a = tic;
TIME(1) = toc(a);

C_old  = C; 
r1_old = 1;
S_old  = S; 
r2_old = 1;
for i = 1:outloop
    
    %% update S
    r2_new = 0.5*(1 + sqrt(1 + 4*r2_old^2));
    S_tilde = S + (r2_old - 1)/r2_new*(S - S_old);
    S_old  = S;
    r2_old = r2_new;
         
    % compute S gradient G_S
    G_S = S_tilde*C'*C - Y3*C;
       
    u = zeros(size(G_S));
    v = zeros(size(G_S));
    for r = 1:R
        Sr = reshape(S_tilde(:,r), [I J]);
        s = reshape(Sr, [I*J, 1]);
        
        ii = [1:I*J]';
        jj = [1:I*J]';
        ssx = ((HX*s).^2 + epsi).^(q/2 - 1);
        U{r} = sparse(ii, jj, ssx ,I*J, I*J);
        ssy = ((HY*s).^2 + epsi).^(q/2 - 1);
        V{r} = sparse(ii, jj, ssy, I*J, I*J);
        
        u(:,r) = HX'*U{r}*HX*s;
        v(:,r) = HY'*V{r}*HY*s;
    end
    
    G_S = G_S + q*eta*(u + v);
    
    % compute C stepsize L_C     
    lu = zeros(R, 1);
    lv = zeros(R, 1);
    for r = 1:R      
        lu(r) = sig_HX*sig_HX*max(max(abs(U{r})));
        lv(r) = sig_HY*sig_HY*max(max(abs(V{r})));
    end
    sig_U = max(lu(:));
    sig_V = max(lv(:));
    
    sig_C = svd(C'*C);
    
    L_S   = max(sig_C) + q*eta*(sig_U + sig_V);

    S  = S_tilde - (1/L_S)*G_S;
   
    St = reshape(S, [I, J, R]);
    for r = 1:R
        [UU, Sig, VV] = svd(St(:,:,r));
        s = diag(Sig);
        s = ProjectOntoL1Ball(s, L);
        Sig = diag(s);
        X(:,:,r) = UU(:,1:numel(s))*Sig*VV(:,1:numel(s))';
    end
    Y = SimplexProj(reshape(X, [I*J, R]));
    
    j = 1;
    inner_err = [];
    inner_err(j) = norm(Y - S,'fro')/norm(S,'fro');
    while inner_err(j) > 1e-3
        j = j + 1;
        Yold  = Y;
        St = reshape(Y, [I, J, R]);
        for r = 1:R
            [UU, Sig, VV] = svd(St(:,:,r));
            s = diag(Sig);
            s = ProjectOntoL1Ball(s, L);
            Sig = diag(s);
            X(:,:,r) = UU(:,1:numel(s))*Sig*VV(:,1:numel(s))';
        end
        Y = SimplexProj(reshape(X, [I*J, R]));      
        inner_err(j) = norm(Y - Yold,'fro')/norm(Yold,'fro');
    end
    S  = Y;
    
    %% Update C
    r1_new  = 0.5*(1 + sqrt(1 + 4*r1_old^2));
    C_tilde = C + (r1_old - 1)/r1_new*(C - C_old);
    C_old   = C;
    r1_old  = r1_new;
 
    % compute C gradient G_C
    G_C = C_tilde*S'*S - Y3'*S;
    
    % compute C stepsize L_C  
    sig_S = svd(S'*S);
    L_C    = max(sig_S);
    
    C = C_tilde - (1/L_C)*G_C;
    C = max(0, C); 
    
    C_err(i) = norm(C - C_old,'fro')/norm(C_old,'fro');
    S_err(i) = norm(S - S_old,'fro')/norm(S_old,'fro');
    %% Stopping value 
    TIME(i+1)  = TIME(i) + toc(a);
    MSE_C(i+1) = MSE_measure(C, C_true);
    MSE_S(i+1) = MSE_measure(S, S_true);
    obj(i+1) = f(SRI, S, C, eta, q, epsi, HX, HY);
    obj_err(i) = abs(obj(i+1) - obj(i))/obj(i);
    if obj_err(i) <= epsilon
        break;
    end
    
    a = tic;
end
    %% Output  
    out.obj = obj;
    out.obj_err = obj_err;
    out.MSE_C = MSE_C;
    out.MSE_S = MSE_S;
    out.TIME  = TIME;
    out.C_err = C_err;
    out.S_err = S_err;
end

function obj_value = f(SRI, S, C, eta, q, epsi, HX, HY)
[I, J, K] = size(SRI);
Y3 = reshape(SRI, [I*J, K]);

obj_value = 0.5*sum(sum((Y3 - S*C').^2)); 

for r = 1:size(S,2)
    s = S(:,r);
    obj_value = obj_value + eta*sum(((HX*s).^2 + epsi).^(q/2))...
        + eta*sum(((HY*s).^2 + epsi).^(q/2));
end
end