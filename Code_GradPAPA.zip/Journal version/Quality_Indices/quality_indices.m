function Out = quality_indices(X,S,ratio)
%--------------------------------------------------------------------------
% Quality Indices
%
% USAGE
%   Out = quality_indices(X,S,ratio)
%
% INPUT
%   X  : recovered SRI data 
%   S  : original SRI data
%   ratio : GSD ratio between HS and MS imagers
%
% OUTPUT
%   Out.rmse : rmse
%   Out.rsnr : rsnr
%   Out.ssim : ssim
%   Out.sam  : sam
%   Out.cc   : cc
%   Out.ergas: ergas
%   Out.uiqi : uiqi
%--------------------------------------------------------------------------  
    Out.rmse = RMSE(X, S);
    
    Out.rsnr = RSNR(X,S);
    
    Out.ssim = ssim3d(X*255, S*255);
    
    cc = CC(X,S);
    Out.cc = mean(cc);
    
    [sam,map] = SAM(X,S);
    Out.sam_map = map;
    Out.sam = sam;
    
    Out.ergas = ERGAS(X,S,ratio);
    
    q_band   = zeros(1, size(X,3));
    for idx1 = 1:size(X,3)
        q_band(idx1)=img_qi(S(:,:,idx1), X(:,:,idx1), 10);
    end
    Out.uiqi = mean(q_band);

end
